package com.telusko;

public class Alien {

	public void code() {
		System.out.println("Coding");
	}
	
}

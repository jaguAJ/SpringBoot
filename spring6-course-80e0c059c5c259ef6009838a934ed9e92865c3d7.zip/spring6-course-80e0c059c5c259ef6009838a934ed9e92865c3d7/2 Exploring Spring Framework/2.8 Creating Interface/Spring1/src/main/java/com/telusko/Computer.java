package com.telusko;

public interface Computer {

	void compile();

}
package com.telusko;

public class Laptop {
	public Laptop() {
		System.out.println("Laptop object created");
	}
}

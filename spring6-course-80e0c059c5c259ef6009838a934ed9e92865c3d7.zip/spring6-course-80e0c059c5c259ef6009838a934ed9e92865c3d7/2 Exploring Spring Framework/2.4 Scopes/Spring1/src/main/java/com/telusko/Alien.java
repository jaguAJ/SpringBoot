package com.telusko;

public class Alien {
	
	int age;

	public Alien() {
		System.out.println("Object Created");
	}
	
	public void code() {
		System.out.println("Coding");
	}
	
}

package com.telusko.app;

import org.springframework.stereotype.Component;

@Component
public class Laptop {
    public void compile(){
        System.out.println("compiling");
    }
}

package com.telusko.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFirstApplicationTests {

    @Test
    void contextLoads() {
    }

}

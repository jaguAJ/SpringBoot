package com.telusko.springsecdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecDemoApplication.class, args);
	}

}
